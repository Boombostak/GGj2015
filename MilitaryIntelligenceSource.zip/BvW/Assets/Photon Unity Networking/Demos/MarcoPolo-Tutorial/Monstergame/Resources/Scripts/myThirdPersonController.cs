
public class myThirdPersonController : ThirdPersonController
{
    // This class replaces the JS version of the same name for this tutorial.
    
    // Actually, the ThirdPersonController works (more or less) the same way as it's JS counterpart
    // but it's much easier to integrate being in C# as well (no need to move files around).

    // Extending the ThirdPersonController into "myThirdPersonController" make sure it uses the same name as in Tutorial.
    
    // Please bear with us for this little fake.
}
